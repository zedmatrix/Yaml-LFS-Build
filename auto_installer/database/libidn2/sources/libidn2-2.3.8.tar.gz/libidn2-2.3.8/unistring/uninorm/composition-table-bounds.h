/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
/* Canonical composition of Unicode characters.  */
/* Generated automatically by gen-uni-tables.c for Unicode 16.0.0.  */

/* Copyright (C) 2009-2024 Free Software Foundation, Inc.

   This file is free software: you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as
   published by the Free Software Foundation; either version 2.1 of the
   License, or (at your option) any later version.

   This file is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* Maximum value of the first argument for which gl_uninorm_compose_lookup
   can return a non-NULL value.  */
#define UNINORM_COMPOSE_MAX_ARG1 0x16d69
/* Maximum value of the second argument for which gl_uninorm_compose_lookup
   can return a non-NULL value.  */
#define UNINORM_COMPOSE_MAX_ARG2 0x16d67
