#include <iostream>
#include "test.hpp"

using namespace std;

int main(void) {
  cout << getStr() << endl;
}
