#pragma once

void cmTestFunc(void);
