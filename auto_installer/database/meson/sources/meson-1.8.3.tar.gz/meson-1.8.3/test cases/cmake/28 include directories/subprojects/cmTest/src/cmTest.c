#include "include/cmTest.h"
#include <stdio.h>

void cmTestFunc(void)
{
    printf ("Hello\n");
}
