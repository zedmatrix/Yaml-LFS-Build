
"""This module has a __version__ that has a type annotation"""

__version__: str = '0.1'
